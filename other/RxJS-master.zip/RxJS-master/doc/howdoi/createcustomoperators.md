# This is RxJS v 4. [Find the latest version here](https://github.com/reactivex/rxjs)
# Creating Your Own Custom Operators

Final Result

```js

```
