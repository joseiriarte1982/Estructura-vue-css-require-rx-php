Keyboard shorcuts is an Observable that emit events when a specified sequence of characters are pressed at the same time.

There is a function to create those Observables, which receives a text as parameter.

Also it has a simple UI to create a and display keyboard shortcut occurrences, which shows usage of several Observables operators.    