(function (Game) {
  
  function Rectangle(x, y, width, height) {
    return {x : x, y : y, width : width, height : height}
  }

  Game.Rectangle = Rectangle;
}(window.Game));
